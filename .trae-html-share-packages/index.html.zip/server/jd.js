import crypto from 'node:crypto'

const appKey = process.env.JD_APPKEY || 'd464919324de83da50d6f88c61cf636a'
const secret = process.env.JD_SECRET || '3df2dab3323e4943b26384832be12765'
// 联盟ID_应用ID_推广位ID
const pid = process.env.JD_PID || '2038416471_4109815216_3110304933'
const siteId = process.env.JD_SITE_ID || '4109815216'
const accessToken = process.env.JD_ACCESS_TOKEN || ''
const apiUrl = process.env.JD_API_URL || 'https://api.jd.com/routerjson'

// 京东联盟精选频道（eliteId 取自《京粉精选商品查询接口》文档）
export const jdCategories = [
  { id: 'all', label: '精选', eliteId: 1, icon: 'ri-sparkling-2-line' },
  { id: 'hot', label: '实时热销', eliteId: 22, icon: 'ri-fire-line' },
  { id: 'recommend', label: '为你推荐', eliteId: 23, icon: 'ri-heart-3-line' },
  { id: 'nine', label: '9.9包邮', eliteId: 10, icon: 'ri-price-tag-3-line' },
  { id: 'delivery', label: '京东配送', eliteId: 15, icon: 'ri-truck-line' },
  { id: 'self', label: '自营好物', eliteId: 110, icon: 'ri-shield-star-line' },
  { id: 'digital', label: '数码家电', eliteId: 24, icon: 'ri-computer-line' },
  { id: 'supermarket', label: '京东超市', eliteId: 25, icon: 'ri-shopping-basket-2-line' },
  { id: 'mother', label: '母婴玩具', eliteId: 26, icon: 'ri-bear-smile-line' },
  { id: 'home', label: '家具日用', eliteId: 27, icon: 'ri-home-5-line' },
  { id: 'beauty', label: '美妆穿搭', eliteId: 28, icon: 'ri-magic-line' },
  { id: 'book', label: '图书文具', eliteId: 30, icon: 'ri-book-open-line' },
  { id: 'today', label: '今日必推', eliteId: 31, icon: 'ri-thumb-up-line' },
  { id: 'seckill', label: '京东秒杀', eliteId: 33, icon: 'ri-flashlight-line' }
]

// 京东 JOS 签名：参数名排序后拼接 key + value，再用 secret 包裹做 MD5。
function signJdParams(params) {
  const source = Object.entries(params)
    .filter(([, value]) => value !== undefined && value !== null && value !== '')
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${key}${value}`)
    .join('')
  return crypto.createHash('md5').update(`${secret}${source}${secret}`, 'utf8').digest('hex').toUpperCase()
}

// 京东要求 GMT+8 时间戳，格式 yyyy-MM-dd HH:mm:ss
function jdTimestamp() {
  return new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString().replace('T', ' ').slice(0, 19)
}

function unwrapJdResponse(payload) {
  if (!payload || typeof payload !== 'object') throw new Error('京东接口返回为空')
  const wrapperKey = Object.keys(payload).find(key => /^jd_union_open_.*_respon[cs]e$/.test(key))
  const wrapper = wrapperKey ? payload[wrapperKey] : payload
  const resultKey = Object.keys(wrapper || {}).find(key => /(queryResult|getResult|Result)$/.test(key))
  let result = resultKey ? wrapper[resultKey] : wrapper
  // 京东联盟网关有时把业务结果序列化成 JSON 字符串
  if (typeof result === 'string') {
    try {
      result = JSON.parse(result)
    } catch {
      throw new Error('京东接口返回内容解析失败')
    }
  }
  if (result?.code === undefined && payload?.code !== undefined) result = payload
  const code = Number(result?.code)
  if (Number.isFinite(code) && code !== 200) {
    throw new Error(result.errorMessage || result.message || `京东接口返回 ${code}`)
  }
  return result || {}
}

async function callJd(method, businessParams) {
  const params = {
    method,
    app_key: appKey,
    timestamp: jdTimestamp(),
    format: 'json',
    v: '1.0',
    sign_method: 'md5',
    '360buy_param_json': JSON.stringify(businessParams)
  }
  if (accessToken) params.access_token = accessToken
  params.sign = signJdParams(params)

  const body = new URLSearchParams(params)
  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded;charset=utf-8' },
    body
  })
  if (!response.ok) throw new Error(`京东接口返回 ${response.status}`)
  return unwrapJdResponse(await response.json())
}

function toArray(value, key) {
  if (!value) return []
  if (Array.isArray(value)) return value
  if (!key) return [value]
  const inner = value[key]
  if (Array.isArray(inner)) return inner
  if (inner && typeof inner === 'object') return [inner]
  return []
}

function normalizeUrl(url) {
  if (!url) return ''
  const text = String(url).trim()
  if (!text) return ''
  if (/^https?:\/\//i.test(text)) return text.replace(/^http:\/\//i, 'https://')
  return `https://${text.replace(/^\/\//, '')}`
}

function collectImages(product) {
  const imageList = product?.imageInfo?.imageList
  const holders = Array.isArray(imageList) ? imageList : [imageList]
  const urls = []
  for (const holder of holders) {
    if (!holder) continue
    if (typeof holder === 'string') {
      urls.push(holder)
      continue
    }
    const list = Array.isArray(holder) ? holder : toArray(holder.urlInfo)
    for (const item of list) {
      const url = typeof item === 'string' ? item : item?.url
      if (url) urls.push(url)
    }
  }
  const whiteImage = product?.imageInfo?.whiteImage
  return [...new Set([...urls, whiteImage].filter(Boolean).map(normalizeUrl))]
}

function collectCoupons(product) {
  const holders = [product?.couponInfo?.couponList, product?.purchasePriceInfo?.couponList]
  const coupons = []
  for (const holder of holders) {
    if (!holder) continue
    const raw = holder.coupon || holder.couponInfo || holder
    coupons.push(...(Array.isArray(raw) ? raw : [raw]))
  }
  return coupons.filter(item => item && typeof item === 'object')
}

// 把京东返回的商品对象整理成与淘宝一致的卡片字段。
function normalizeJdProduct(item, index) {
  const images = collectImages(item)
  const image = images[0] || ''
  if (!image) return null

  const originalPrice = Number(item?.priceInfo?.price || 0) || 0
  const promotionPrice = Number(item?.priceInfo?.lowestPrice || originalPrice) || originalPrice
  const finalPrice = Number(item?.priceInfo?.lowestCouponPrice || promotionPrice) || promotionPrice
  const coupon = collectCoupons(item).find(entry => Number(entry.discount) > 0)
  const couponAmount = Number(coupon?.discount || 0) || Math.max(0, promotionPrice - finalPrice)
  const owner = String(item?.owner || '').trim()
  const link = normalizeUrl(item?.materialUrl || item?.clickURL || (item?.skuId ? `item.jd.com/${item.skuId}.html` : ''))

  return {
    id: String(item?.skuId || item?.itemId || `jd-${index}`),
    title: item?.skuName || '京东精选好物',
    shop: item?.shopInfo?.shopName || '京东商家',
    image,
    images,
    originalPrice: Number(originalPrice.toFixed(2)),
    finalPrice: Number(finalPrice.toFixed(2)),
    coupon: Number(couponAmount.toFixed(2)),
    couponQuota: Number(coupon?.quota || 0) || 0,
    couponLink: normalizeUrl(coupon?.link),
    sold: Number(item?.inOrderCount30Days || 0) || 0,
    tag: couponAmount > 0 ? '京东优惠券' : (owner === 'g' ? '京东自营' : '京东精选'),
    link,
    source: 'jd'
  }
}

function extractProductList(result) {
  const data = result?.data || {}
  const raw = data.jfGoodsResp ?? data.materialGoodsResp ?? data.goodsResp ?? []
  const list = Array.isArray(raw) ? raw : (raw ? [raw] : [])
  return list.map(normalizeJdProduct).filter(product => product?.link && product?.image)
}

export async function fetchJdProducts({ categoryId, page, size, query }) {
  const result = query
    ? await callJd('jd.union.open.goods.query', {
        goodsReqDTO: {
          keyword: query,
          pageIndex: page,
          pageSize: size,
          pid,
          sortName: 'inOrderCount30Days',
          sort: 'desc'
        }
      })
    : await callJd('jd.union.open.goods.jingfen.query', {
        goodsReq: {
          eliteId: (jdCategories.find(item => item.id === categoryId) || jdCategories[0]).eliteId,
          pageIndex: page,
          pageSize: size,
          pid
        }
      })

  const products = extractProductList(result)
  const totalCount = Number(result?.totalCount ?? result?.data?.totalCount ?? 0) || 0
  const hasMore = products.length >= size && (totalCount ? page * size < totalCount : true)
  return { products, hasMore, totalCount }
}

export const jdConfig = { pid, siteId }
